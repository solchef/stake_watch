<?php
/*
Plugin Name: Stake Watch Core
Description: A WordPress plugin to display stake_watch charts.
Version: 1.0
Author: DSGN
*/


// Enqueue scripts and styles
function stake_watch_core_enqueue_scripts() {
}
add_action('wp_enqueue_scripts', 'stake_watch_core_enqueue_scripts');

