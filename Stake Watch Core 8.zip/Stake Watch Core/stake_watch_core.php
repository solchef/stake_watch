<?php
/*
Plugin Name: Stake Watch Core
Description: A plugin to display price index data and analysis.
Version: 1.0
Author: Stake Watch
*/

// Include or require the functions file
require_once plugin_dir_path(__FILE__) . 'functions.php';

function stake_watch_core_shortcode($atts)
{
    // Fetch API data
    $price_index_data = fetch_api_data();
    $analysis_data = generate_analysis_data($price_index_data);
    ob_start();
    ?>
    <?php echo $analysis_data['1m_price']; ?>

    <?php echo $analysis_data['1m_chg']; ?>

    <?php echo $analysis_data['1m_aagr']; ?>

    <?php echo $analysis_data['3m_price']; ?>

    <?php echo $analysis_data['3m_chg']; ?>

    <?php echo $analysis_data['3m_aagr']; ?>

    <?php echo $analysis_data['6m_price']; ?>

    <?php echo $analysis_data['6m_chg']; ?>

    <?php echo $analysis_data['6m_aagr']; ?>

    <?php echo $analysis_data['1y_price']; ?>


    <!-- <script>
        google.charts.load('current', { 'packages': ['corechart'] });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Date');
            data.addColumn('number', 'Price');

            // Add data rows
            <?php foreach ($price_index_data as $data_point): ?>
                data.addRow(['<?php echo $data_point['x']['label']; ?>', <?php echo $data_point['y']['max']['value']; ?>]);
            <?php endforeach; ?>

            var options = {
                title: 'Price Index',
                curveType: 'function',
                legend: { position: 'bottom' },
                backgroundColor: 'transparent', // Set background color to transparent
                colors: ['green', 'yellow'] // Set line gradient colors
            };

            var chart = new google.visualization.LineChart(document.getElementById('price_index_chart'));
            chart.draw(data, options);
        }
    </script>
     -->

    <?php
    return ob_get_clean();
}
add_shortcode('stake_watch_core', 'stake_watch_core_shortcode');
?>